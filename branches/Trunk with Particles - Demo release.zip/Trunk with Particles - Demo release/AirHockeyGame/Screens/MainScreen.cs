using System.Text;
using DemoBaseXNA;
using DemoBaseXNA.DrawingSystem;
using DemoBaseXNA.ScreenSystem;
using FarseerGames.FarseerPhysics;
using FarseerGames.FarseerPhysics.Dynamics;
using FarseerGames.FarseerPhysics.Factories;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FarseerGames.AirHockeyGame.Screens {
    public class MainScreen : GameScreen {

        private Paddle playerPaddle;
        private Puck puck;

        public override void Initialize() {
            PhysicsSimulator = new PhysicsSimulator(new Vector2(0, 0));
            PhysicsSimulatorView = new PhysicsSimulatorView(PhysicsSimulator);
            base.Initialize();
        }

        public override void LoadContent() {

            //Load puck
            this.puck = new Puck(ScreenManager.ContentManager.Load<Texture2D>("Content\\Game\\puck"), 48, new Vector2(725, 384), PhysicsSimulator);
            
            //Load playerPaddle
            this.playerPaddle = new Paddle(ScreenManager.ContentManager.Load<Texture2D>("Content\\Game\\playerPaddle"), 82, new Vector2(256, 384), PhysicsSimulator);
            GeomFactory.Instance.CreateCircleGeom(PhysicsSimulator, this.playerPaddle.body, (int)this.playerPaddle.width / 2, (int)this.playerPaddle.width);
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime) {
            ScreenManager.SpriteBatch.Begin(SpriteBlendMode.AlphaBlend);

            ScreenManager.SpriteBatch.Draw(puck.texture, puck.rect, Color.White);
            ScreenManager.SpriteBatch.Draw(playerPaddle.texture, playerPaddle.rect, Color.White);

            ScreenManager.SpriteBatch.End();

            base.Draw(gameTime);
        }

        public override void HandleInput(InputState input) {
            if(firstRun) {
                ScreenManager.AddScreen(new PauseScreen(GetTitle(), GetDetails()));
                firstRun = false;
            }
            if(input.PauseGame) {
                ScreenManager.AddScreen(new PauseScreen(GetTitle(), GetDetails()));
            }

            //Particles
            //TODO: Make this useful!
            if (input.IsNewKeyPress(Keys.Space))
            {
                ScreenManager.RequestParticleEffect('e', playerPaddle.position);
            }
            if (input.IsNewKeyPress(Keys.F))
            {
                ScreenManager.RequestParticleEffect('s', puck.position);
            }

            base.HandleInput(input);
        }

        private Vector2 previousMouse, currentMouse;

        public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen) {

            //Prevent menu mouse movements passing on to game
            if(coveredByOtherScreen || otherScreenHasFocus) {
                this.playerPaddle.ResetMouse();
            }

            this.currentMouse = new Vector2(Mouse.GetState().X, Mouse.GetState().Y);


            //Calculate the mouse's difference in position from the last update

            if((previousMouse != currentMouse) || previousMouse == null) {

                Vector2 diff;

                diff.X = this.currentMouse.X - this.playerPaddle.body.Position.X;
                diff.Y = this.currentMouse.Y - this.playerPaddle.body.Position.Y;

                //Apply a force accordingly
                this.playerPaddle.ApplyForce(new Vector2((diff.X * 60), diff.Y * 60));
                //Move the mouse to the new location
                this.playerPaddle.ResetMouse();
            }
            this.previousMouse = this.currentMouse;

            //Update playerPaddle and puck objects
            this.playerPaddle.Update();
            this.puck.Update();
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }


        public static string GetTitle() {
            return "Play Game";
        }

        private static string GetDetails() {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("This is where we wait for all players to be ready");
            sb.AppendLine(string.Empty);
            sb.AppendLine("Use the mouse to control your paddle.");
            sb.AppendLine("Defend your goal while attacking your opponent's.");
            return sb.ToString();
        }
    }
}